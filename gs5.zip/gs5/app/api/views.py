from tokenize import group
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.http import Http404
from django.db.models import Q

from ..models import GroupMessage, User, OneToOneMessage,Attachments,GroupInfo
from .serializers import AttachmentSerializer, OneToOneMessageSerializer,GroupMessageSerializer,GroupInfoSerializer


class OneToOneMessagesListAPIView(APIView):
    serializer_class = OneToOneMessageSerializer
    def get(self, request, format=None):
        if self.request.query_params.get('receiver'):
            try:
                query_param = User.objects.get(username=self.request.query_params.get('receiver'))
                qs = OneToOneMessage.objects.filter(
                    Q(receiver=self.request.user, sender=query_param) |
                    Q(sender=self.request.user, receiver=query_param)).order_by('-created_at')
            except:
                return Response(data={},  status=status.HTTP_404_NOT_FOUND)
        else:
            qs = OneToOneMessage.objects.filter(
                Q(sender=self.request.user) |
                Q(receiver=self.request.user)).order_by('-created_at')
        serializer = OneToOneMessageSerializer(qs, many=True)
        return Response(data=serializer.data,  status=status.HTTP_404_NOT_FOUND)


    def post(self, request, format=None):
        serializer = OneToOneMessageSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class OneToOneMessagesDetailAPIView(APIView):
    def get_object(self, pk):
        try:
            return OneToOneMessage.objects.get(pk=pk)
        except OneToOneMessage.DoesNotExist:
            raise Http404

    def get(self, request, pk, format=None):
        qs = self.get_object(pk)
        serializer = OneToOneMessageSerializer(qs)
        return Response(serializer.data)

    def put(self, request, pk, format=None):
        qs = self.get_object(pk)
        serializer = OneToOneMessageSerializer(qs, data=request.data,partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    

class AttachmentsView(APIView):
    queryset = Attachments.objects.all()
    serializer_class = AttachmentSerializer

    def post(self, request, *args, **kwargs):
        serializer = AttachmentSerializer(data=request.data,context={'request': request})
        if serializer.is_valid():
            serializer.save()
            custom_data = {
                "status": True,
                "message": 'Attachment successfully uploaded',
                "data": serializer.data
            }
            return Response(custom_data, status=status.HTTP_201_CREATED)
        else:
            custom_data = {
                "status": False,
                "message": serializer.errors,
            }
            return Response(custom_data, status=status.HTTP_200_OK)


    def get(self, request, format=None):
        snippets = Attachments.objects.all()
        serializer = AttachmentSerializer(snippets, many=True)
        return Response(serializer.data)


class GroupInfoView(APIView):
    queryset = GroupInfo.objects.all()
    serializer_class = GroupInfoSerializer

    def get(self, request, format=None):
        group = GroupInfo.objects.all()
        serializer = GroupInfoSerializer(group, many=True)
        print(serializer)
        return Response(serializer.data)

    def post(self, request, *args, **kwargs):
        serializer = AttachmentSerializer(data=request.data,context={'request': request})
        if serializer.is_valid():
            serializer.save()
            custom_data = {
                "status": True,
                "message": 'Attachment successfully uploaded',
                "data": serializer.data
            }
            return Response(custom_data, status=status.HTTP_201_CREATED)
        else:
            custom_data = {
                "status": False,
                "message": serializer.errors,
            }
            return Response(custom_data, status=status.HTTP_200_OK)
    

class GroupMessageView(APIView):
    queryset = GroupMessage.objects.all()
    serializer_class = GroupMessageSerializer

    def get(self, request, format=None):
        group = GroupMessage.objects.filter(sender = request.user)
        serializer = GroupMessageSerializer(group, many=True)
        return Response(serializer.data)