import uuid
from django.db import models
from django.db.models import Q
from django.utils.translation import gettext_lazy as _
from django.contrib.auth.models import AbstractBaseUser
from typing import Optional, Any

from user.models import User

class BaseModel(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    class Meta:
    	abstract = True


class BaseTimestampedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class ChatCommonFieldsModelMixin(BaseTimestampedModel):
    MESSAGE_TYPE = (
        ('ONE_TO_ONE', 'one_to_one'),
        ('GROUP', 'group'),
    )

    MESSAGE_CONTENT_FORMAT = (
        ('TEXT', 'text'),
        ('AUDIO', 'audio'),
        ('VIDEO', 'video'),
        ('FILE', 'file'),
        ('IMAGE', 'image'),
    )

    content = models.TextField(verbose_name=_("Text"), blank=False, null=True)
    message_type = models.CharField(max_length=10, choices=MESSAGE_TYPE, default="one_to_one")
    message_format = models.CharField(max_length=10, choices=MESSAGE_CONTENT_FORMAT, default="text")
    is_delete = models.BooleanField(default=False)

    class Meta:
        abstract = True


class Attachments(BaseModel,BaseTimestampedModel):
    uploaded_by = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name=_("Uploaded_by"), related_name='uploaded_by', db_index=True)
    file = models.FileField(verbose_name=_("File"), blank=False, null=False, upload_to='attachments')
    upload_date = models.DateTimeField(auto_now_add=True, verbose_name=_("Upload date"))

    def __str__(self):
        return str(self.file.name)


class OneToOneGroup(BaseModel,BaseTimestampedModel):
    name = models.CharField(max_length=255, blank=False)
    sender = models.ForeignKey(User, related_name='one_to_one_sender',on_delete=models.CASCADE, verbose_name=_("sender"))
    receiver = models.ForeignKey(User, related_name='one_to_one_receiver',on_delete=models.CASCADE, verbose_name=_("receiver"))

    class Meta:
        unique_together = (('sender', 'receiver'), ('receiver', 'sender'))
        verbose_name = _("OneToOneGroup")
        verbose_name_plural = _("OneToOneGroups")

    def __str__(self) -> str:
        return _("Conversation between ") + f"{self.sender_id},{self.receiver_id}"

    @staticmethod
    def conversation_exists(u1: AbstractBaseUser, u2: AbstractBaseUser) -> Optional[Any]:
        return OneToOneGroup.objects.filter(Q(sender=u1, receiver=u2) | Q(sender=u2, receiver=u1)).first()

    @staticmethod
    def create_if_not_exists(u1: AbstractBaseUser, u2: AbstractBaseUser,*args):
        res = OneToOneGroup.conversation_exists(u1, u2)
        if not res:
            OneToOneGroup.objects.create(sender=u1, receiver=u2)

    @staticmethod
    def get_conversation_for_user(user: AbstractBaseUser):
        return OneToOneGroup.objects.filter(Q(sender=user) | Q(receiver=user)).values_list('sender__pk', 'receiver__pk')


class OneToOneMessage(BaseModel,ChatCommonFieldsModelMixin):
    sender = models.ForeignKey(User, related_name='from_sender', on_delete=models.CASCADE, verbose_name=_("Author"))
    receiver = models.ForeignKey(User, related_name='to_receiver', on_delete=models.CASCADE, verbose_name=_("Receiver"))
    file = models.ManyToManyField(Attachments,related_name='message', verbose_name=_("Attachment"), blank=True, null=True)
    is_read = models.BooleanField(default=False)

    def save(self, *args, **kwargs):
        super(OneToOneMessage, self).save(*args, **kwargs)
        OneToOneGroup.create_if_not_exists(self.sender, self.receiver)

    def uploaded_files(self):
        return ",".join([str(files) for files in self.file.all()])

    class Meta:
        ordering = ('-created_at',)
        verbose_name = "OneToOneMessage"
        verbose_name_plural = "OneToOneMessages"

    def __str__(self):
        return str(self.id)
    

class GroupInfo(BaseModel,BaseTimestampedModel):
    name = models.CharField(max_length=255, blank=False, verbose_name=_("Group Name"))
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name=_("created by"))

    @property
    def message_model_ref(self): return self.grp_participants.all()

    class Meta:
        ordering = ('-created_at',)
        verbose_name = _("GroupInfo")
        verbose_name_plural = _("GroupInfos")
    
    def __str__(self) -> str:
        return str(self.name)
    

class GroupMessage(BaseModel,ChatCommonFieldsModelMixin):
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name="grp_senders")
    participants = models.ManyToManyField(User, related_name="grp_participants")
    group = models.ForeignKey(GroupInfo , on_delete=models.CASCADE,related_name="grp_group_name",null=True, blank=True)
    file = models.ManyToManyField(Attachments,related_name='grp_attachments', verbose_name=_("Attachment"), blank=True, null=True)

    def files(self):
        return ",".join([str(files) for files in self.file.all()])
    
    def members(self):
        return ",".join([str(participants) for participants in self.participants.all()])
    
    class Meta:
        verbose_name = _("GroupMessage")
        verbose_name_plural = _("GroupMessages")

    def __str__(self) -> str:
        return str(self.id)