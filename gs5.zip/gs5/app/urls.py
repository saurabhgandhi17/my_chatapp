from django.urls import include, path
from rest_framework import routers
from app.api import views as app_view
from user.api import views as user_view


router = routers.DefaultRouter()

urlpatterns = [
    path('users/', user_view.UsersViewSet.as_view({'get': 'list'}), name='users_list'),
    path('messages/', app_view.OneToOneMessagesListAPIView.as_view(), name='messages_list'),
    path('messages/<str:pk>/', app_view.OneToOneMessagesDetailAPIView.as_view(), name='messages_details'),
    path('file/', app_view.AttachmentsView.as_view(), name='file'),
    path('groups/', app_view.GroupInfoView.as_view(), name='groups'),
    path('groups_messages/', app_view.GroupMessageView.as_view(), name='groups_messages'),
    path('', include(router.urls)),
]

urlpatterns += router.urls
